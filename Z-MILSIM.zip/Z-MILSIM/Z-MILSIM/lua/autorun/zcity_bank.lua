--[[
    ZCity Bank - SINGLE FILE VERSION
    Put this file in:   garrysmod/lua/autorun/zcity_bank.lua
    (or inside the Z-City folder:  Z-City/lua/autorun/zcity_bank.lua)
    NOT in autorun/server or autorun/client - it must be in plain "autorun".

    - $ per kill, saved in the server's SQLite database
    - private chat commands:  !bank  !stats  !money  !kills   (console: bank)
    - admin: zbank_give / zbank_take / zbank_set / zbank_check / zbank_test
    - debug: zbank_debug 1
]]

ZBank = ZBank or {}

if SERVER then AddCSLuaFile() end

-- ======================= CONFIG =======================
ZBank.Config = ZBank.Config or {}
ZBank.Config = {
    KillReward      = 50,     -- money per kill
    NotifyOnKill    = true,   -- private chat message to the killer when they get paid
    SaveInterval    = 30,     -- seconds between saves of changed data
    LastHitWindow   = 30,     -- seconds: if a player dies from bleeding/world etc., the last
                              -- player who hurt them within this time gets the kill
    CommandCooldown = 0.8,    -- anti-spam for the chat commands (seconds)
    Prefix          = "[BANK] ",

    -- chat command  ->  what it shows
    -- (summary = money + kills + deaths + K/D, money = only money, kills = kills/deaths/K/D)
    Commands = {
        ["!bank"]  = "summary", ["/bank"]  = "summary",
        ["!stats"] = "summary", ["/stats"] = "summary",
        ["!money"] = "money",   ["/money"] = "money",
        ["!kills"] = "kills",   ["/kills"] = "kills",
    },
}

-- ======================= SERVER =======================
if SERVER then

local CFG = ZBank.Config

util.AddNetworkString("ZBank_Msg")
util.AddNetworkString("ZBank_Request")

local MSG = { SUMMARY = 1, MONEY = 2, KILLS = 3, REWARD = 4, ADMIN = 5 }

local cvDebug = CreateConVar("zbank_debug", "0", FCVAR_NONE, "Print ZBank debug info to the server console")

local function Dbg(fmt, ...)
    if cvDebug:GetBool() then
        MsgC(Color(205, 119, 84), "[ZBank] ", color_white, string.format(fmt, ...), "\n")
    end
end

-- =====================================================================
--  DATABASE
-- =====================================================================
if sql.Query([[
    CREATE TABLE IF NOT EXISTS zcity_bank (
        steamid TEXT PRIMARY KEY,
        name    TEXT,
        money   INTEGER NOT NULL DEFAULT 0,
        kills   INTEGER NOT NULL DEFAULT 0,
        deaths  INTEGER NOT NULL DEFAULT 0
    )
]]) == false then
    ErrorNoHalt("[ZBank] Could not create table: " .. tostring(sql.LastError()) .. "\n")
end

local Data = {}   -- [key] = { name, money, kills, deaths, dirty }
ZBank.Data = Data

-- DB key: SteamID64, with fallbacks so local/self-hosted tests never break
local function Key(ply)
    local sid = ply:SteamID64()
    if not sid or sid == "" or sid == "0" then sid = ply:SteamID() end
    if not sid or sid == "" or sid == "NULL" then sid = "local_" .. ply:Nick() end
    return sid
end

-- find an entry (cache, then DB). create = true makes a new empty one.
local function Entry(key, name, create)
    local e = Data[key]
    if e then return e end

    local row = sql.QueryRow("SELECT name, money, kills, deaths FROM zcity_bank WHERE steamid = " .. sql.SQLStr(key))
    if row then
        e = {
            name   = row.name or key,
            money  = tonumber(row.money)  or 0,
            kills  = tonumber(row.kills)  or 0,
            deaths = tonumber(row.deaths) or 0,
        }
    elseif create then
        e = { name = name or key, money = 0, kills = 0, deaths = 0, dirty = true }
    else
        return nil
    end

    Data[key] = e
    return e
end

local function SaveEntry(key)
    local e = Data[key]
    if not e then return end

    local q = string.format(
        "REPLACE INTO zcity_bank (steamid, name, money, kills, deaths) VALUES (%s, %s, %d, %d, %d)",
        sql.SQLStr(key), sql.SQLStr(tostring(e.name or key)),
        math.floor(e.money), math.floor(e.kills), math.floor(e.deaths)
    )

    if sql.Query(q) == false then
        ErrorNoHalt("[ZBank] Save error: " .. tostring(sql.LastError()) .. "\n")
    else
        e.dirty = false
    end
end

local function SaveDirty()
    sql.Begin()
    for key, e in pairs(Data) do
        if e.dirty then SaveEntry(key) end
    end
    sql.Commit()
end

local function Get(ply)
    if not IsValid(ply) or not ply:IsPlayer() or ply:IsBot() then return end
    local e = Entry(Key(ply), ply:Nick(), true)
    e.name = ply:Nick()
    return e
end

-- =====================================================================
--  PUBLIC API  (use from other addons: shops, etc.)
-- =====================================================================
function ZBank.GetStats(ply) return Get(ply) end

function ZBank.GetMoney(ply)
    local e = Get(ply)
    return e and e.money or 0
end

function ZBank.AddMoney(ply, amount)
    local e = Get(ply)
    if not e then return false end
    e.money = math.max(0, e.money + math.floor(amount))
    e.dirty = true
    return true
end

function ZBank.SetMoney(ply, amount)
    local e = Get(ply)
    if not e then return false end
    e.money = math.max(0, math.floor(amount))
    e.dirty = true
    return true
end

-- returns false (and takes nothing) if the player can't afford it
function ZBank.TakeMoney(ply, amount)
    local e = Get(ply)
    amount = math.floor(amount)
    if not e or e.money < amount then return false end
    e.money = e.money - amount
    e.dirty = true
    return true
end

function ZBank.CanAfford(ply, amount)
    return ZBank.GetMoney(ply) >= amount
end

-- player meta shortcuts
local PLAYER = FindMetaTable("Player")
function PLAYER:BankGetMoney()      return ZBank.GetMoney(self) end
function PLAYER:BankAddMoney(n)     return ZBank.AddMoney(self, n) end
function PLAYER:BankTakeMoney(n)    return ZBank.TakeMoney(self, n) end
function PLAYER:BankSetMoney(n)     return ZBank.SetMoney(self, n) end

-- =====================================================================
--  MESSAGES (private, formatted on the client)
-- =====================================================================
local function Send(ply, kind, money, kills, deaths, extra, text)
    if not IsValid(ply) then return end
    net.Start("ZBank_Msg")
        net.WriteUInt(kind, 4)
        net.WriteDouble(money or 0)
        net.WriteDouble(kills or 0)
        net.WriteDouble(deaths or 0)
        net.WriteDouble(extra or 0)
        net.WriteString(text or "")
    net.Send(ply) -- ONLY this player
end

-- =====================================================================
--  CHAT / CONSOLE COMMANDS
-- =====================================================================
local KindToMsg = { summary = MSG.SUMMARY, money = MSG.MONEY, kills = MSG.KILLS }
local cooldown = {}

local function ShowCommand(ply, kind)
    if not IsValid(ply) then return end

    cooldown[ply] = cooldown[ply] or {}
    if (cooldown[ply][kind] or 0) > CurTime() then return end
    cooldown[ply][kind] = CurTime() + CFG.CommandCooldown

    local e = Get(ply)
    local msg = KindToMsg[kind]
    if not e or not msg then return end

    Send(ply, msg, e.money, e.kills, e.deaths)
end

-- chat, server side. Returning "" hides the command from everyone.
hook.Add("PlayerSay", "ZBank_Chat", function(ply, text)
    local kind = CFG.Commands[string.lower(string.Trim(text))]
    if not kind then return end
    ShowCommand(ply, kind)
    return ""
end)

-- chat, client side intercept (backup in case another addon swallows PlayerSay)
net.Receive("ZBank_Request", function(_, ply)
    local kind = CFG.Commands[string.lower(net.ReadString() or "")]
    if kind then ShowCommand(ply, kind) end
end)

-- console: type  bank  or  zbank
concommand.Add("bank",  function(ply) ShowCommand(ply, "summary") end)
concommand.Add("zbank", function(ply) ShowCommand(ply, "summary") end)

-- =====================================================================
--  KILL TRACKING
-- =====================================================================

-- remember the last player who hurt each player (used when the death hook
-- does not tell us who killed them, e.g. bleeding out)
hook.Add("EntityTakeDamage", "ZBank_TrackHit", function(target, dmg)
    if not IsValid(target) or not target:IsPlayer() then return end

    local atk = dmg:GetAttacker()
    if IsValid(atk) and not atk:IsPlayer() then
        local o = atk:GetOwner()
        if IsValid(o) and o:IsPlayer() then atk = o end
    end

    if IsValid(atk) and atk:IsPlayer() and atk ~= target then
        target.ZBankLastHit = { ply = atk, time = CurTime() }
    end
end)

local function AsPlayer(ent)
    if not IsValid(ent) then return end
    if ent:IsPlayer() then return ent end
    local o = ent.GetOwner and ent:GetOwner()
    if IsValid(o) and o:IsPlayer() then return o end
end

local function ResolveKiller(victim, inflictor, attacker)
    local k = AsPlayer(attacker) or AsPlayer(inflictor)
    if k and k ~= victim then return k, "direct" end

    local lh = victim.ZBankLastHit
    if lh and IsValid(lh.ply) and lh.ply ~= victim and (CurTime() - lh.time) <= CFG.LastHitWindow then
        return lh.ply, "last hit"
    end
end

local function CreditKill(killer, victim)
    local e = Get(killer)
    if not e then return end

    e.kills = e.kills + 1
    e.money = e.money + CFG.KillReward
    e.dirty = true

    Dbg("%s killed %s: +$%d -> $%d", killer:Nick(), IsValid(victim) and victim:Nick() or "?", CFG.KillReward, e.money)

    if CFG.NotifyOnKill then
        Send(killer, MSG.REWARD, e.money, e.kills, e.deaths, CFG.KillReward, IsValid(victim) and victim:Nick() or "")
    end
end

local function ProcessDeath(victim, inflictor, attacker, source)
    if not IsValid(victim) or not victim:IsPlayer() then return end

    -- several hooks can fire for one death: count it only once
    if victim.ZBankDead then return end
    victim.ZBankDead = true
    victim.ZBankDeadTime = CurTime()

    local killer, how = ResolveKiller(victim, inflictor, attacker)

    Dbg("death [%s] victim=%s attacker=%s inflictor=%s -> killer=%s (%s)",
        source, victim:Nick(), tostring(attacker), tostring(inflictor),
        killer and killer:Nick() or "none", how or "-")

    local vd = Get(victim)
    if vd then
        vd.deaths = vd.deaths + 1
        vd.dirty = true
    end

    if killer then CreditKill(killer, victim) end

    victim.ZBankLastHit = nil
end

hook.Add("DoPlayerDeath", "ZBank_DoDeath", function(victim, attacker, dmginfo)
    ProcessDeath(victim, dmginfo and dmginfo:GetInflictor() or nil, attacker, "DoPlayerDeath")
end)

hook.Add("PlayerDeath", "ZBank_Death", function(victim, inflictor, attacker)
    ProcessDeath(victim, inflictor, attacker, "PlayerDeath")
end)

-- some gamemodes kill players with KillSilent, which skips PlayerDeath
hook.Add("PlayerSilentDeath", "ZBank_SilentDeath", function(victim)
    ProcessDeath(victim, nil, nil, "PlayerSilentDeath")
end)

hook.Add("PlayerSpawn", "ZBank_Spawn", function(ply)
    ply.ZBankDead = false
    ply.ZBankWasAlive = true
    ply.ZBankLastHit = nil
end)

-- last-resort fallback: detect alive -> dead even if no death hook fired
timer.Create("ZBank_DeathPoll", 0.25, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() then
            ply.ZBankWasAlive = true
            -- safety: if we flagged a death but the player is clearly alive again
            if ply.ZBankDead and (CurTime() - (ply.ZBankDeadTime or 0)) > 2 then
                ply.ZBankDead = false
            end
        elseif ply.ZBankWasAlive then
            ply.ZBankWasAlive = false
            ProcessDeath(ply, nil, nil, "poll")
        end
    end
end)

-- =====================================================================
--  LOAD / SAVE
-- =====================================================================
hook.Add("PlayerInitialSpawn", "ZBank_Load", function(ply)
    Get(ply)
end)

hook.Add("PlayerDisconnected", "ZBank_Leave", function(ply)
    if IsValid(ply) and not ply:IsBot() then
        local key = Key(ply)
        if Data[key] then
            Data[key].dirty = true
            SaveEntry(key)
            Data[key] = nil
        end
    end
    cooldown[ply] = nil
end)

hook.Add("ShutDown", "ZBank_Shutdown", SaveDirty)
timer.Create("ZBank_Autosave", CFG.SaveInterval, 0, SaveDirty)

-- already-connected players (after a lua refresh)
for _, ply in ipairs(player.GetAll()) do
    Get(ply)
    ply.ZBankWasAlive = ply:Alive()
end

-- =====================================================================
--  ADMIN COMMANDS  (server console or superadmins)
--    zbank_give  <name|steamid64> <amount>
--    zbank_take  <name|steamid64> <amount>
--    zbank_set   <name|steamid64> <amount>
--    zbank_check <name|steamid64>
--    zbank_test                (gives YOU a fake kill, to test the chat)
-- =====================================================================
local function Reply(caller, msg)
    if IsValid(caller) then
        caller:PrintMessage(HUD_PRINTCONSOLE, msg .. "\n")
    else
        print(msg)
    end
end

local function AllowedAdmin(caller)
    if not IsValid(caller) then return true end
    if caller:IsSuperAdmin() or caller:IsListenServerHost() then return true end
    caller:PrintMessage(HUD_PRINTCONSOLE, "[ZBank] Superadmin only.\n")
    return false
end

-- returns key, online player (or nil)
local function FindTarget(arg)
    if not arg or arg == "" then return end

    if string.match(arg, "^%d+$") and #arg >= 15 then
        for _, p in ipairs(player.GetAll()) do
            if p:SteamID64() == arg then return arg, p end
        end
        return arg, nil
    end

    local lower = string.lower(arg)
    for _, p in ipairs(player.GetAll()) do
        if string.find(string.lower(p:Nick()), lower, 1, true) then
            return Key(p), p
        end
    end
end

local function AdminModify(name, usage, fn)
    concommand.Add(name, function(caller, _, args)
        if not AllowedAdmin(caller) then return end

        local key, ply = FindTarget(args[1])
        local amount = tonumber(args[2])
        if not key or not amount then
            Reply(caller, "[ZBank] Usage: " .. usage)
            return
        end

        local e = ply and Get(ply) or Entry(key, nil, false)
        if not e then
            Reply(caller, "[ZBank] Unknown player: " .. tostring(args[1]))
            return
        end

        fn(e, math.floor(amount))
        e.dirty = true
        if not ply then SaveEntry(key) end

        Reply(caller, string.format("[ZBank] %s now has $%d", e.name or key, e.money))

        if ply and name == "zbank_give" then
            Send(ply, MSG.ADMIN, e.money, e.kills, e.deaths, math.floor(amount))
        end
    end)
end

AdminModify("zbank_give", "zbank_give <name|steamid64> <amount>", function(e, n) e.money = math.max(0, e.money + n) end)
AdminModify("zbank_take", "zbank_take <name|steamid64> <amount>", function(e, n) e.money = math.max(0, e.money - n) end)
AdminModify("zbank_set",  "zbank_set <name|steamid64> <amount>",  function(e, n) e.money = math.max(0, n) end)

concommand.Add("zbank_check", function(caller, _, args)
    if not AllowedAdmin(caller) then return end

    local key, ply = FindTarget(args[1])
    local e = key and (ply and Get(ply) or Entry(key, nil, false))
    if not e then
        Reply(caller, "[ZBank] Usage: zbank_check <name|steamid64>  (player not found)")
        return
    end

    local kd = e.deaths > 0 and math.Round(e.kills / e.deaths, 2) or e.kills
    Reply(caller, string.format("[ZBank] %s (%s)  $%d | %d kills | %d deaths | K/D %s",
        e.name or key, key, e.money, e.kills, e.deaths, tostring(kd)))
end)

concommand.Add("zbank_test", function(caller)
    if not IsValid(caller) or not AllowedAdmin(caller) then return end
    CreditKill(caller, nil)
    Reply(caller, "[ZBank] Test kill given to you.")
end)

print("[ZCity Bank] Loaded. Reward: $" .. CFG.KillReward .. " per kill.")

end

-- ======================= CLIENT =======================
if CLIENT then

local CFG = ZBank.Config

local clay  = Color(205, 119, 84)
local light = Color(228, 160, 125)
local grey  = Color(170, 150, 140)
local white = Color(255, 255, 255)

local function Num(n)
    return string.Comma(math.floor(n))
end

local function KD(kills, deaths)
    return deaths > 0 and tostring(math.Round(kills / deaths, 2)) or tostring(math.floor(kills))
end

local tag = CFG.Prefix

local Handlers = {
    -- 1: summary
    [1] = function(money, kills, deaths)
        chat.AddText(clay, tag, white, "Balance: ", light, "$" .. Num(money))
        chat.AddText(clay, tag, white, "Kills: ", light, Num(kills),
                     grey, "  |  ", white, "Deaths: ", light, Num(deaths),
                     grey, "  |  ", white, "K/D: ", light, KD(kills, deaths))
    end,

    -- 2: money only
    [2] = function(money)
        chat.AddText(clay, tag, white, "Balance: ", light, "$" .. Num(money))
    end,

    -- 3: kills only
    [3] = function(_, kills, deaths)
        chat.AddText(clay, tag, white, "Kills: ", light, Num(kills),
                     grey, "  |  ", white, "Deaths: ", light, Num(deaths),
                     grey, "  |  ", white, "K/D: ", light, KD(kills, deaths))
    end,

    -- 4: kill reward
    [4] = function(money, kills, _, gain, victim)
        local who = (victim and victim ~= "") and (" " .. victim) or ""
        chat.AddText(clay, tag, light, "+$" .. Num(gain), grey, " kill" .. who,
                     grey, "  |  ", white, "Balance: ", light, "$" .. Num(money),
                     grey, "  |  ", white, "Kills: ", light, Num(kills))
    end,

    -- 5: admin gave money
    [5] = function(money, _, _, amount)
        chat.AddText(clay, tag, white, "An admin gave you ", light, "$" .. Num(amount),
                     grey, "  |  ", white, "Balance: ", light, "$" .. Num(money))
    end,
}

net.Receive("ZBank_Msg", function()
    local kind   = net.ReadUInt(4)
    local money  = net.ReadDouble()
    local kills  = net.ReadDouble()
    local deaths = net.ReadDouble()
    local extra  = net.ReadDouble()
    local text   = net.ReadString()

    local h = Handlers[kind]
    if h then h(money, kills, deaths, extra, text) end
end)

-- catch the command in our own chat: hides it and asks the server
hook.Add("OnPlayerChat", "ZBank_ChatIntercept", function(ply, text)
    if ply ~= LocalPlayer() then return end

    local cmd = string.lower(string.Trim(text))
    if not CFG.Commands[cmd] then return end

    net.Start("ZBank_Request")
        net.WriteString(cmd)
    net.SendToServer()

    return true
end)

end
